/** @type {import('ts-jest').JestConfigWithTsJest} **/
module.exports = {
  preset: "ts-jest",
  testEnvironment: "jsdom",
  transform: {
    "^.+\\.tsx?$": "ts-jest",
  },
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
    "\\.(css|scss|less)$": "identity-obj-proxy",
    "^axios$": "<rootDir>/__mocks__/axios.ts",
  },
  transformIgnorePatterns: ["/node_modules/(?!axios)/"],
  setupFilesAfterEnv: ["<rootDir>/src/setupTests.ts"],
};
