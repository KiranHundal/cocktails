module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Varela Round", "sans-serif"],
      },
      colors: {
        primary: "#4F46E5",
        secondary: "#F3F4F6",
        background: "#F9FAFB",
        card: {
          dark: "rgba(0, 0, 0, 0.5)",
          darker: "rgba(0, 0, 0, 0.7)",
        },
      },
      spacing: {
        4: "16px",
        8: "32px",
        16: "64px",
      },
      screens: {
        sm: "640px",
        md: "768px",
        lg: "1024px",
        xl: "1280px",
      },
      backgroundImage: {
        "bar-pattern": "url('../assets/bg.jpg')",
      },
    },
  },
  plugins: [],
};
