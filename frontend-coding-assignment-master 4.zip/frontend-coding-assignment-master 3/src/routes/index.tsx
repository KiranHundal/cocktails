import React, { lazy } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { ROUTES } from "../constants/routes";

const SearchPage = lazy(() => import("../pages/SearchPage"));
const DetailsPage = lazy(() => import("../pages/DetailsPage"));

export const AppRoutes: React.FC = () => (
  <Routes>
    <Route path={ROUTES.HOME} element={<SearchPage />} />
    <Route path={ROUTES.DETAILS} element={<DetailsPage />} />
    <Route path="*" element={<Navigate to={ROUTES.HOME} replace />} />
  </Routes>
);
