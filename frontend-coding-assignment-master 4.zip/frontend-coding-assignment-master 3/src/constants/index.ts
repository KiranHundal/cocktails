export const CONSTANTS = {
  API: {
    BASE_URL: "/api",
    ENDPOINTS: {
      SEARCH: "search.json",
      DETAILS: "detail.json",
    },
    TIMEOUT: 5000,
  },
  THEME: {
    COLORS: {
      BACKGROUND: {
        DEFAULT: "rgba(0, 0, 0, 0.9)",
        CARD: "rgba(0, 0, 0, 0.5)",
        OVERLAY: "rgba(0, 0, 0, 0.7)",
      },
      TEXT: {
        PRIMARY: "#FFFFFF",
        SECONDARY: "rgba(255, 255, 255, 0.7)",
      },
      BORDER: {
        DEFAULT: "rgba(255, 255, 255, 0.6)",
      },
    },
  },
  PAGINATION: {
    ITEMS_PER_PAGE: 6,
    DEFAULT_PAGE: 0,
    MAX_VISIBLE_PAGES: 5,
  },
  ROUTES: {
    HOME: "/",
    DETAILS: "/details/:id",
  },
} as const;
export const { PAGINATION } = CONSTANTS;

