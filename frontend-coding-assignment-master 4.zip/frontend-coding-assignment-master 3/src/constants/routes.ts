export const ROUTES = {
  HOME: "/",
  DETAILS: "/details/:id",
} as const;
