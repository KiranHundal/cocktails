export const CONFIG = {
  BASE_URL: "https://barcraft.com",
  SHARE_PATH: "/share",
} as const;
