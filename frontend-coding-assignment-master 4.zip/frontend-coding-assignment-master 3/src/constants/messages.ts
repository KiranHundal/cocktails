export const messages = [
  "No cocktails found, try again!",
  "Even the bartender is confused...",
  "Shake it up! Try another search.",
  "No drinks? Somebody call the manager!",
  "No results... maybe just pour yourself some water? 💧",
] as const;
