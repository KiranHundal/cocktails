import React, { Suspense } from "react";
import { BrowserRouter } from "react-router-dom";
import { LoadingSpinner } from "./components/common/LoadingSpinner";
import { AppProvider } from "./providers/AppProvider";
import { AppRoutes } from "./routes";

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AppProvider>
        <Suspense fallback={<LoadingSpinner />}>
          <AppRoutes />
        </Suspense>
      </AppProvider>
    </BrowserRouter>
  );
};

export default App;
