import axios, { AxiosInstance } from "axios";
import { jest } from "@jest/globals";

const mockAxiosInstance = {
  get: jest.fn(),
  post: jest.fn(),
  put: jest.fn(),
  delete: jest.fn(),
  interceptors: {
    request: { use: jest.fn(), eject: jest.fn() },
    response: { use: jest.fn(), eject: jest.fn() },
  },
  defaults: {
    headers: {
      common: {},
    },
  },
} as unknown as AxiosInstance;

const mockAxios = {
  create: jest.fn(() => mockAxiosInstance),
  ...mockAxiosInstance,
} as unknown as jest.Mocked<typeof axios>;

export default mockAxios;
