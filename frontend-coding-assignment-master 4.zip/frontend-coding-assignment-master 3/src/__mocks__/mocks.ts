export const mockCocktail = {
  id: 1,
  name: "Margarita",
  category: "Cocktail",
  image: "margarita.jpg",
  instructions: "Mix ingredients",
  container: "Cocktail glass",
  ingredients: [
    { name: "Tequila", measurement: "2 oz" },
    { name: "Lime juice", measurement: "1 oz" },
  ],
};

export const mockSearchResponse = {
  drinks: [mockCocktail],
  totalCount: 1,
};

export const mockApiError = {
  message: "An error occurred",
  status: 500,
};
