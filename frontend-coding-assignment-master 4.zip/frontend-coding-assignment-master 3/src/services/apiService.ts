import axios from "axios";
import { CONSTANTS } from "../constants";
import type {
  SearchResponse,
  CocktailDetailsResponse,
} from "../types/cocktail";

const axiosInstance = axios.create({
  baseURL: CONSTANTS.API.BASE_URL,
  timeout: CONSTANTS.API.TIMEOUT,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      console.error("API Error:", error.response.status, error.response.data);
    }
    return Promise.reject(error);
  }
);

export const searchCocktails = async (
  index: number,
  limit: number,
  query: string
): Promise<SearchResponse> => {
  const { data } = await axiosInstance.get<SearchResponse>(
    CONSTANTS.API.ENDPOINTS.SEARCH,
    { params: { index, limit, query } }
  );
  return data;
};

export const getCocktailDetails = async (
  id: number
): Promise<CocktailDetailsResponse> => {
  const { data } = await axiosInstance.get<CocktailDetailsResponse>(
    CONSTANTS.API.ENDPOINTS.DETAILS,
    { params: { id } }
  );
  return data;
};
