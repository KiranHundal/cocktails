import { render, screen } from "../../../utils/test-utils";
import { CocktailDetails } from "../../../components/cocktails/CocktailDetails";
import { mockedData } from "../../../__setup__/test-setup";

describe("CocktailDetails", () => {
  it("renders ingredients list correctly", () => {
    const { ingredients } = mockedData.cocktail;
    render(<CocktailDetails cocktail={mockedData.cocktail} />);

    ingredients.forEach((ingredient) => {
      expect(
        screen.getByText(new RegExp(ingredient.name, "i"))
      ).toBeInTheDocument();
      expect(
        screen.getByText(new RegExp(ingredient.measurement, "i"))
      ).toBeInTheDocument();
    });
  });

  it("renders share section with correct URL", () => {
    render(<CocktailDetails cocktail={mockedData.cocktail} />);
    const expectedUrl = `https://barcraft.com/share/margarita`;
    expect(screen.getByDisplayValue(expectedUrl)).toBeInTheDocument();
  });
});
