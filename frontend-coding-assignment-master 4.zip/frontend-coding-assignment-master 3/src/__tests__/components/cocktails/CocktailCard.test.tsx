import { render, screen, fireEvent } from "../../../utils/test-utils";
import { CocktailCard } from "../../../components/cocktails/CocktailCard";
import { mockedData } from "../../../__setup__/test-setup";

jest.mock("../../../providers/AppProvider", () => ({
  useApp: () => ({
    announceMessage: jest.fn(),
    setError: jest.fn(),
    isReducedMotion: false,
    announcement: "",
    clearAnnouncement: jest.fn(),
  }),
  AppProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

describe("CocktailCard", () => {
  const mockOnClick = jest.fn();

  it("renders cocktail information", () => {
    render(
      <CocktailCard cocktail={mockedData.cocktail} onClick={mockOnClick} />
    );
    expect(screen.getByText(mockedData.cocktail.name)).toBeInTheDocument();
    expect(screen.getByText(mockedData.cocktail.category)).toBeInTheDocument();
  });

  it("handles click events", () => {
    render(
      <CocktailCard cocktail={mockedData.cocktail} onClick={mockOnClick} />
    );
    fireEvent.click(screen.getByLabelText(/view details for/i));
    expect(mockOnClick).toHaveBeenCalled();
  });

  it("handles keyboard navigation", () => {
    render(
      <CocktailCard cocktail={mockedData.cocktail} onClick={mockOnClick} />
    );
    fireEvent.keyDown(screen.getByLabelText(/view details for/i), {
      key: "Enter",
    });
    expect(mockOnClick).toHaveBeenCalled();
  });
});
