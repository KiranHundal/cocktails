import { render, screen } from "../../../utils/test-utils";
import { IngredientsList } from "../../../components/cocktails/IngredientsList";
import { mockedData } from "../../../__setup__/test-setup";

describe("IngredientsList", () => {
  it("renders ingredients correctly", () => {
    const { ingredients } = mockedData.cocktail;
    render(<IngredientsList ingredients={ingredients} />);

    expect(
      screen.getByText(`${ingredients.length} Ingredients`)
    ).toBeInTheDocument();

    ingredients.forEach((ingredient) => {
      expect(
        screen.getByText(
          new RegExp(`${ingredient.measurement} ${ingredient.name}`)
        )
      ).toBeInTheDocument();
    });
  });
});
