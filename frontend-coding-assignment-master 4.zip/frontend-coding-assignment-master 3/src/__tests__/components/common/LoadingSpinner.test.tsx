import { render, screen } from "../../../utils/test-utils";
import { LoadingSpinner } from "../../../components/common/LoadingSpinner";

describe("LoadingSpinner", () => {
  it("renders correctly", () => {
    render(<LoadingSpinner />);
    expect(screen.getByText("Searching...")).toBeInTheDocument();
  });

  it("applies correct size class", () => {
    render(<LoadingSpinner size="sm" />);

    // Using getByAltText with empty string
    const spinner = screen.getByAltText("", { exact: true });
    expect(spinner).toHaveClass("w-8 h-8");
  });
});

