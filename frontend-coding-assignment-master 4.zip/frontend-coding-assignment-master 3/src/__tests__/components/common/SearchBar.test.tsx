import { render, screen, fireEvent } from "../../../utils/test-utils";
import { SearchBar } from "../../../components/common/SearchBar";

describe("SearchBar", () => {
  const defaultProps = {
    value: "",
    onChange: jest.fn(),
    onSearch: jest.fn(),
    isLoading: false,
  };

  it("renders correctly", () => {
    render(<SearchBar {...defaultProps} />);
    expect(screen.getByRole("searchbox")).toBeInTheDocument();
  });

  it("handles input changes", () => {
    render(<SearchBar {...defaultProps} />);
    const input = screen.getByRole("searchbox");
    fireEvent.change(input, { target: { value: "test" } });
    expect(defaultProps.onChange).toHaveBeenCalledWith("test");
  });

  it("triggers search on enter", () => {
    render(<SearchBar {...defaultProps} />);
    const input = screen.getByRole("searchbox");
    fireEvent.keyDown(input, { key: "Enter" });
    expect(defaultProps.onSearch).toHaveBeenCalled();
  });

  it("shows loading state", () => {
    render(<SearchBar {...defaultProps} isLoading={true} />);
    expect(screen.getByRole("button")).toBeDisabled();
  });
});
