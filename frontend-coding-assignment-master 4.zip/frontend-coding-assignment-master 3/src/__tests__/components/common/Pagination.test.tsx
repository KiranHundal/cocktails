import { render, screen, fireEvent } from "../../../utils/test-utils";
import { Pagination } from "../../../components/common/Pagination";

describe("Pagination", () => {
  const defaultProps = {
    currentPage: 0,
    totalPages: 5,
    onPageChange: jest.fn(),
  };

  it("renders pagination buttons", () => {
    render(<Pagination {...defaultProps} />);
    expect(
      screen.getByRole("button", { name: /previous/i })
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /next/i })).toBeInTheDocument();
  });

  it("disables previous button on first page", () => {
    render(<Pagination {...defaultProps} currentPage={0} />);
    expect(screen.getByRole("button", { name: /previous/i })).toBeDisabled();
  });

  it("disables next button on last page", () => {
    render(<Pagination {...defaultProps} currentPage={4} />);
    expect(screen.getByRole("button", { name: /next/i })).toBeDisabled();
  });

  it("handles page changes", () => {
    render(<Pagination {...defaultProps} currentPage={1} />);
    fireEvent.click(screen.getByRole("button", { name: /next/i }));
    expect(defaultProps.onPageChange).toHaveBeenCalledWith(2);
  });
});
