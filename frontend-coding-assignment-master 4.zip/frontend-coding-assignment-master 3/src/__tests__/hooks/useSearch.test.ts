import { renderHook, act, waitFor } from "@testing-library/react";
import { useSearch } from "../../hooks/useSearch";
import { searchCocktails } from "../../services/apiService";
import { mockedData, errorMessages } from "../../__setup__/test-setup";

jest.mock("../../services/apiService", () => ({
  searchCocktails: jest.fn(),
}));

describe("useSearch", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it("initializes with default values", () => {
    const { result } = renderHook(() => useSearch());

    expect(result.current.query).toBe("");
    expect(result.current.cocktails).toEqual([]);
    expect(result.current.loading).toBe(true);
  });

  it("handles successful search", async () => {
    (searchCocktails as jest.Mock).mockResolvedValue(mockedData.searchResponse);
    const { result } = renderHook(() => useSearch());

    await act(async () => {
      result.current.setQuery("margarita");
      await result.current.handleSearch();
    });

    await waitFor(() => {
      expect(result.current.cocktails).toEqual(
        mockedData.searchResponse.drinks
      );
      expect(result.current.loading).toBe(false);
    });
  });

  it("handles search errors", async () => {
    (searchCocktails as jest.Mock).mockRejectedValue(
      errorMessages.networkError
    );
    const { result } = renderHook(() => useSearch());

    await act(async () => {
      result.current.setQuery("margarita");
      await result.current.handleSearch();
    });

    await waitFor(() => {
      expect(result.current.cocktails).toEqual([]);
      expect(result.current.loading).toBe(false);
    });
  });

  it("uses cached data when available", async () => {
    const cachedData = {
      drinks: mockedData.searchResponse.drinks,
      totalCount: 1,
    };

    localStorage.setItem(
      "cocktail-search-margarita-0",
      JSON.stringify(cachedData)
    );

    const { result, rerender } = renderHook(() => useSearch());

    await act(async () => {
      result.current.setQuery("margarita");
    });

    rerender();

    await waitFor(() => {
      expect(result.current.cocktails).toEqual(
        mockedData.searchResponse.drinks
      );
      expect(result.current.loading).toBe(false);
    });
  });

  it("handles JSON parsing errors in cache", async () => {
    localStorage.setItem("cocktail-search-margarita-1", "{invalid json}");
    const { result } = renderHook(() => useSearch());

    await act(async () => {
      result.current.setQuery("margarita");
      await result.current.handleSearch();
    });

    await waitFor(() => {
      expect(result.current.cocktails).toEqual([]);
    });
  });
});
