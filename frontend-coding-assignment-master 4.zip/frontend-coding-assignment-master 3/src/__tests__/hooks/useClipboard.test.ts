import { renderHook, act, waitFor } from "@testing-library/react";
import { useClipboard } from "../../hooks/useClipboard";
import { setupClipboardMock } from "../../__setup__/test-setup";

describe("useClipboard", () => {
  beforeEach(setupClipboardMock);

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
  });

  it("copies text to clipboard", async () => {
    const { result } = renderHook(() => useClipboard());

    await act(async () => {
      await result.current.copyToClipboard("test text");
    });

    expect(navigator.clipboard.writeText).toHaveBeenCalledWith("test text");
    await waitFor(() => {
      expect(result.current.copied).toBe(true);
    });
  });

  it("resets copied state after duration", async () => {
    jest.useFakeTimers();
    const { result } = renderHook(() => useClipboard(1000));

    await act(async () => {
      await result.current.copyToClipboard("test text");
    });

    expect(result.current.copied).toBe(true);

    act(() => {
      jest.advanceTimersByTime(1000);
    });

    await waitFor(() => {
      expect(result.current.copied).toBe(false);
    });
  });

  it("handles clipboard write errors gracefully", async () => {
    jest
      .spyOn(navigator.clipboard, "writeText")
      .mockRejectedValue(new Error("Clipboard write failed"));

    const { result } = renderHook(() => useClipboard());

    await act(async () => {
      await result.current.copyToClipboard("test text");
    });

    expect(navigator.clipboard.writeText).toHaveBeenCalledWith("test text");
    expect(result.current.copied).toBe(false);
  });
});
