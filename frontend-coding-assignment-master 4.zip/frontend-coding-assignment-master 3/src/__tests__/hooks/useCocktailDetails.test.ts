import { renderHook, act } from "@testing-library/react";
import { useCocktailDetails } from "../../hooks/useCocktailDetails";
import { getCocktailDetails } from "../../services/apiService";
import { mockedData, errorMessages } from "../../__setup__/test-setup";

jest.mock("../../services/apiService");

describe("useCocktailDetails", () => {
  it("fetches cocktail details", async () => {
    (getCocktailDetails as jest.Mock).mockResolvedValue({
      drinks: [mockedData.cocktail],
    });

    const { result } = renderHook(() => useCocktailDetails("1"));
    expect(result.current.loading).toBe(true);

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    expect(result.current.cocktail).toEqual(mockedData.cocktail);
    expect(result.current.loading).toBe(false);
  });

  it("handles errors", async () => {
    (getCocktailDetails as jest.Mock).mockRejectedValue(
      errorMessages.fetchError
    );
    const { result } = renderHook(() => useCocktailDetails("1"));

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    expect(result.current.error).toBeTruthy();
    expect(result.current.loading).toBe(false);
  });
});
