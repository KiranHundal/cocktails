import axios from "axios";
import { searchCocktails, getCocktailDetails } from "../../services/apiService";
import { errorMessages, mockedData } from "../../__setup__/test-setup";

type MockAxiosType = {
  create: jest.Mock;
  get: jest.Mock;
  interceptors: {
    request: { use: jest.Mock };
    response: { use: jest.Mock };
  };
};

jest.mock("axios", () => {
  const mockAxios: MockAxiosType = {
    create: jest.fn(),
    get: jest.fn(),
    interceptors: {
      request: { use: jest.fn() },
      response: { use: jest.fn() },
    },
  };

  mockAxios.create.mockReturnValue(mockAxios);
  return mockAxios;
});

describe("apiService", () => {
  describe("searchCocktails", () => {
    it("fetches cocktails successfully", async () => {
      (axios.get as jest.Mock).mockResolvedValue({
        data: mockedData.searchResponse,
      });

      const result = await searchCocktails(0, 10, "margarita");

      expect(result).toEqual(mockedData.searchResponse);
      expect(axios.get).toHaveBeenCalledWith(
        expect.stringContaining("search.json"),
        expect.any(Object)
      );
    });

    it("handles search errors", async () => {
      (axios.get as jest.Mock).mockRejectedValue(errorMessages.apiError);
      await expect(searchCocktails(0, 10, "error")).rejects.toThrow(
        "API Error"
      );
    });
  });

  describe("getCocktailDetails", () => {
    it("fetches cocktail details successfully", async () => {
      (axios.get as jest.Mock).mockResolvedValue({
        data: { drinks: [mockedData.cocktail] },
      });

      const result = await getCocktailDetails(1);

      expect(result.drinks).toContainEqual(mockedData.cocktail);
      expect(axios.get).toHaveBeenCalledWith(
        expect.stringContaining("detail.json"),
        expect.any(Object)
      );
    });

    it("handles detail fetch errors", async () => {
      (axios.get as jest.Mock).mockRejectedValue(errorMessages.apiError);
      await expect(getCocktailDetails(1)).rejects.toThrow("API Error");
    });
  });
});
