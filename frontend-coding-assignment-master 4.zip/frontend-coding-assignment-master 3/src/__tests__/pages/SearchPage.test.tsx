import { render, screen, fireEvent, waitFor } from "../../utils/test-utils";
import SearchPage from "../../pages/SearchPage";
import { searchCocktails } from "../../services/apiService";
import { mockedData } from "../../__setup__/test-setup";
import { messages } from "../../constants/messages";jest.mock("../../services/apiService");

describe("SearchPage", () => {
  it("renders search interface", () => {
    render(<SearchPage />);
    expect(screen.getByRole("searchbox")).toBeInTheDocument();
    expect(screen.getByText("All Drinks")).toBeInTheDocument();
  });

  it("displays search results", async () => {
    (searchCocktails as jest.Mock).mockResolvedValue(mockedData.searchResponse);
    render(<SearchPage />);

    const searchInput = screen.getByRole("searchbox");
    fireEvent.change(searchInput, { target: { value: "margarita" } });
    fireEvent.click(screen.getByText("GO"));

    await waitFor(() => {
      expect(
        screen.getByText(mockedData.searchResponse.drinks[0].name)
      ).toBeInTheDocument();
    });
  });

  it("handles no results state", async () => {
    (searchCocktails as jest.Mock).mockResolvedValue(mockedData.emptyResponse);
    render(<SearchPage />);

    const searchInput = screen.getByRole("searchbox");
    fireEvent.change(searchInput, { target: { value: "nonexistent" } });
    fireEvent.click(screen.getByText("GO"));

   await waitFor(() => {
     expect(
       screen.getByText((content) =>
         messages.includes(content as (typeof messages)[number])
       )
     ).toBeInTheDocument();
   });
  });
});
