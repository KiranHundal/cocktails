import { render, screen, waitFor } from "../../utils/test-utils";
import DetailsPage from "../../pages/DetailsPage";
import { getCocktailDetails } from "../../services/apiService";
import { mockedData, errorMessages } from "../../__setup__/test-setup";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: () => ({ id: "1" }),
}));

jest.mock("../../services/apiService");

describe("DetailsPage", () => {
  beforeEach(jest.clearAllMocks);

  it("displays cocktail details", async () => {
    (getCocktailDetails as jest.Mock).mockResolvedValue({
      drinks: [mockedData.cocktail],
    });

    render(<DetailsPage />);

    await waitFor(() => {
      expect(screen.getByText(mockedData.cocktail.name)).toBeInTheDocument();
    });

    await waitFor(() => {
      expect(
        screen.getByText(mockedData.cocktail.instructions)
      ).toBeInTheDocument();
    });
  }); 

  it("shows loading state", () => {
    (getCocktailDetails as jest.Mock).mockImplementation(
      () => new Promise((resolve) => setTimeout(resolve, 100))
    );

    render(<DetailsPage />);
    expect(screen.getByText(/searching/i)).toBeInTheDocument();
  });

  it("handles error state", async () => {
    (getCocktailDetails as jest.Mock).mockRejectedValue(
      errorMessages.fetchError
    );

    render(<DetailsPage />);

    await waitFor(() => {
      expect(screen.getByText(/no drinks found/i)).toBeInTheDocument();
    });
  });
});
