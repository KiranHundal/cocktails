export interface Ingredient {
  name: string;
  measurement: string;
}

export interface Cocktail {
  id: number;
  name: string;
  category: string;
  image: string;
  instructions: string;
  container: string;
  ingredients: Ingredient[];
}

export interface SearchResponse {
  drinks: Cocktail[];
  totalCount: number;
}

export interface CocktailDetailsResponse {
  drinks: Cocktail[];
}
