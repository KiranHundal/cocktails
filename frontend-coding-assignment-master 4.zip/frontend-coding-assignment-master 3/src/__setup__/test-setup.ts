import { mockCocktail, mockSearchResponse } from "../__mocks__/mocks";
export const setupClipboardMock = () => {
  Object.assign(navigator, {
    clipboard: {
      writeText: jest.fn().mockResolvedValue(undefined),
    },
  });
};

export const mockedData = {
  cocktail: mockCocktail,
  searchResponse: mockSearchResponse,
  emptyResponse: {
    drinks: [],
    totalCount: 0,
  },
};

export const errorMessages = {
  apiError: new Error("API Error"),
  networkError: new Error("Network Error"),
  fetchError: new Error("Failed to fetch"),
};
