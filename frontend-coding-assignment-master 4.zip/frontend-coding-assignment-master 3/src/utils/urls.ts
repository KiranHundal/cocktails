import { CONFIG } from "../constants/config";

export const getShareUrl = (name: string) => {
  const formattedName = name.toLowerCase().replace(/\s+/g, "-");
  return `${CONFIG.BASE_URL}${CONFIG.SHARE_PATH}/${formattedName}`;
};
