import React, {
  createContext,
  useContext,
  ReactNode,
  useState,
  useCallback,
  useEffect,
} from "react";
import { ErrorBoundary } from "../components/layout/ErrorBoundary";
import { useNavigate } from "react-router-dom";

interface AppContextType {
  setError: (error: Error) => void;
  announceMessage: (message: string) => void;
  isReducedMotion: boolean;
  announcement: string;
  clearAnnouncement: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [announcement, setAnnouncement] = useState("");
  const navigate = useNavigate();

  const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  const handleError = (error: Error) => {
    console.error("Application Error:", error);
    announceMessage(`Error: ${error.message}`);
  };

   const announceMessage = useCallback((message: string) => {
     setAnnouncement(message);
   }, []);
  const clearAnnouncement = useCallback(() => {
    setAnnouncement("");
  }, []);
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Search focus
      if (e.key === "/" && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        const searchInput = document.querySelector(
          "#cocktail-search"
        ) as HTMLInputElement;
        if (searchInput) {
          searchInput.focus();
          announceMessage("Search focused");
        }
      }

      if (e.key === "h" && (e.altKey || e.metaKey)) {
        e.preventDefault();
        navigate("/");
        announceMessage("Navigated to home");
      }

      if (e.key === "Escape") {
        const searchInput = document.querySelector(
          "#cocktail-search"
        ) as HTMLInputElement;
        if (searchInput === document.activeElement) {
          searchInput.value = "";
          announceMessage("Search cleared");
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [navigate, announceMessage]);
  return (
    <AppContext.Provider
      value={{
        setError: handleError,
        announceMessage,
        announcement,
        clearAnnouncement,
        isReducedMotion: prefersReducedMotion,
      }}
    >
      <div role="alert" aria-live="polite" className="sr-only">
        {announcement}
      </div>
      <ErrorBoundary onError={handleError}>{children}</ErrorBoundary>
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within AppProvider");
  }
  return context;
};
