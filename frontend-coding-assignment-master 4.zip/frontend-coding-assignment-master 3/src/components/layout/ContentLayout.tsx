import React, { memo } from "react";

interface ContentLayoutProps {
  children: React.ReactNode;
  maxWidth?: "sm" | "md" | "lg" | "xl" | "2xl" | "7xl";
}

export const ContentLayout = memo<ContentLayoutProps>(
  ({ children, maxWidth = "7xl" }) => (
    <div className={`px-8 max-w-${maxWidth} mx-auto`}>{children}</div>
  )
);

ContentLayout.displayName = "ContentLayout";
