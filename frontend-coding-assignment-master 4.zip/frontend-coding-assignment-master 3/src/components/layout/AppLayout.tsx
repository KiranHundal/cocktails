import React, { memo } from "react";
import { useApp } from "../../providers/AppProvider";
import defaultBg from "../../assets/bg.jpg";

interface AppLayoutProps {
  children: React.ReactNode;
  backgroundImage?: string;
}

export const AppLayout = memo<AppLayoutProps>(
  ({ children, backgroundImage }) => {
    const { isReducedMotion } = useApp();

    return (
      <div
        className={`
        min-h-screen bg-cover bg-center
        ${isReducedMotion ? "transition-none" : "transition-all duration-300"}
      `}
        style={{
          backgroundImage: `url(${backgroundImage || defaultBg})`,
          backgroundColor: "#000", 
        }}
      >
        <div
          className="min-h-screen bg-black/90"
          role="region"
          aria-label="Main content area"
        >
          {children}
        </div>
      </div>
    );
  }
);

AppLayout.displayName = "AppLayout";
