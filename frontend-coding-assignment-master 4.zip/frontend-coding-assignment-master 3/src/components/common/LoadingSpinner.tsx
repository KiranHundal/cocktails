import React, { memo, useEffect } from "react";
import { useApp } from "../../providers/AppProvider";
import spinnerIcon from "../../assets/spinner.svg";

export interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
}

const sizeMap = {
  sm: "w-8 h-8",
  md: "w-12 h-12",
  lg: "w-16 h-16",
} as const;

export const LoadingSpinner = memo<LoadingSpinnerProps>(({ size = "lg" }) => {
  const { announceMessage } = useApp();

  useEffect(() => {
    announceMessage("Loading content...");
    return () => announceMessage("Loading complete");
  }, [announceMessage]);

  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md z-50"
      role="alert"
      aria-busy="true"
      aria-live="polite"
    >
      <img
        src={spinnerIcon}
        alt=""
        className={`${sizeMap[size]} animate-spin filter invert`}
        aria-hidden="true"
      />

      <p className="mt-4 text-white text-lg font-['Varela Round']">
        Searching...
      </p>
    </div>
  );
});

LoadingSpinner.displayName = "LoadingSpinner";
