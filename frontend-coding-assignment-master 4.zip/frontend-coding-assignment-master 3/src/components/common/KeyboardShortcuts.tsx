import React, { memo } from "react";

interface Shortcut {
  key: string;
  description: string;
}

const SHORTCUTS: Shortcut[] = [
  { key: "/", description: "Focus search" },
  { key: "Esc", description: "Clear search" },
  { key: "←→", description: "Navigate cocktails" },
  { key: "↑↓", description: "Navigate grid rows" },
  { key: "Alt + H", description: "Go home" },
];

export const KeyboardShortcuts = memo(() => {
  return (
    <div
      className="fixed bottom-4 right-4 p-4 bg-black/80 rounded-lg border border-white/20 
                 shadow-lg backdrop-blur-sm z-50 text-white"
      role="tooltip"
    >
      <h2 className="text-sm font-semibold mb-2">Keyboard Shortcuts</h2>
      <ul className="space-y-1">
        {SHORTCUTS.map(({ key, description }) => (
          <li key={key} className="text-sm flex items-center space-x-2">
            <kbd className="px-2 py-1 bg-white/10 rounded text-xs">{key}</kbd>
            <span>{description}</span>
          </li>
        ))}
      </ul>
    </div>
  );
});
