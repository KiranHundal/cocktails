import React, { memo, useEffect } from "react";
import { useApp } from "../../providers/AppProvider";

export const Toast = memo(() => {
  const { announcement, clearAnnouncement } = useApp();

  useEffect(() => {
    if (announcement) {
      const timer = setTimeout(clearAnnouncement, 3000);
      return () => clearTimeout(timer);
    }
  }, [announcement, clearAnnouncement]);

  if (!announcement) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-4 right-4 p-4 bg-black/80 rounded-lg border border-white/20 
                 shadow-lg backdrop-blur-sm z-50 text-white transition-opacity duration-300"
    >
      {announcement}
    </div>
  );
});
