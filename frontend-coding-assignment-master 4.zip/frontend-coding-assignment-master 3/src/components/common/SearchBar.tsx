import React, { memo, useCallback, useRef, useEffect } from "react";
import { useApp } from "../../providers/AppProvider";
import searchIcon from "../../assets/Search-Icon.svg";

export interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onSearch: () => void;
  className?: string;
  placeholder?: string;
  isLoading?: boolean;
}

export const SearchBar = memo<SearchBarProps>(
  ({
    value,
    onChange,
    onSearch,
    className = "",
    placeholder = "Search all drinks",
    isLoading = false,
  }) => {
    const { announceMessage } = useApp();
    const inputRef = useRef<HTMLInputElement>(null);

    const handleKeyDown = useCallback(
      (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === "Enter" && !isLoading) {
          onSearch();
          announceMessage("Searching cocktails...");
        }
      },
      [onSearch, isLoading, announceMessage]
    );

    useEffect(() => {
      inputRef.current?.focus();
    }, []);

    return (
      <div
        role="search"
        aria-label="Search cocktails"
        className={`flex justify-center w-full ${className}`}
      >
        <div className="flex items-center min-w-[257px] h-10 bg-black/20 border-2 border-white/30 rounded-[8px]">
          <label htmlFor="cocktail-search" className="sr-only">
            Search cocktails
          </label>

          <div className="flex items-center pl-6" aria-hidden="true">
            <img src={searchIcon} alt="" className="w-8 h-8 opacity-70" />
          </div>

          <input
            ref={inputRef}
            id="cocktail-search"
            type="search"
            role="searchbox"
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            className="px-4 py-2 bg-transparent text-white text-sm placeholder-white/70 
                   focus:outline-none focus:ring-2 focus:ring-white/50 w-full"
            disabled={isLoading}
            aria-label="Search cocktails"
            aria-describedby="search-description"
            aria-busy={isLoading}
          />

          <div className="border-l border-white/30 h-full">
            <button
              onClick={onSearch}
              disabled={isLoading}
              className="h-full px-6 text-white text-sm font-normal 
                     hover:bg-white/10 focus:ring-2 focus:ring-white/50 
                     focus:outline-none transition-colors whitespace-nowrap 
                     disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label={isLoading ? "Searching..." : "Search cocktails"}
            >
              {isLoading ? "..." : "GO"}
            </button>
          </div>
        </div>

        <div id="search-description" className="sr-only">
          Type your search query and press Enter or click the GO button to
          search for cocktails
        </div>
      </div>
    );
  }
);

SearchBar.displayName = "SearchBar";
