import React from "react";
import { useNavigate } from "react-router-dom";
import { SearchBar } from "../common/SearchBar";

export interface PageHeaderProps {
  title?: string;
  showSearch?: boolean;
  query?: string;
  setQuery?: (value: string) => void;
  handleSearch?: () => void;
}

export const PageHeader: React.FC<PageHeaderProps> = ({
  title = "BarCraft",
  showSearch = false,
  query = "",
  setQuery = () => {},
  handleSearch = () => {},
}) => {
  const navigate = useNavigate();

  return (
    <div
      className="flex items-center justify-between w-full px-8 relative"
      style={{
        height: "70px",
        borderBottom: "0.5px solid #FFFFFF33",
        marginBottom: "58px",
      }}
    >
      <h1
        className="text-[24px] leading-[24px] tracking-[-0.01em] 
        font-['Varela Round'] font-normal text-white cursor-pointer"
        onClick={() => navigate("/")}
        aria-label="Return to home page"
      >
        {title}
      </h1>

      {showSearch && (
        <div className="absolute left-1/2 transform -translate-x-1/2 w-full max-w-lg">
          <SearchBar
            value={query}
            onChange={setQuery}
            onSearch={handleSearch}
            className="w-full"
          />
        </div>
      )}
    </div>
  );
};
