import React, { memo } from "react";
import prevIcon from "../../assets/Prev-Icon.svg";
import nextIcon from "../../assets/Next-Icon.svg";

interface PaginationButtonProps {
  direction: "prev" | "next";
  onClick: () => void;
  disabled: boolean;
}

export const PaginationButton = memo<PaginationButtonProps>(
  ({ direction, onClick, disabled }) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className="
      w-8 h-8 rounded-lg 
      bg-neutral-700/50
      border border-white/60 
      flex items-center justify-center 
      disabled:opacity-50 
      hover:bg-opacity-70 
      transition-all
    "
    >
      <img
        src={direction === "prev" ? prevIcon : nextIcon}
        alt={direction === "prev" ? "Previous" : "Next"}
        className="w-4 h-4"
      />
    </button>
  )
);

PaginationButton.displayName = "PaginationButton";
