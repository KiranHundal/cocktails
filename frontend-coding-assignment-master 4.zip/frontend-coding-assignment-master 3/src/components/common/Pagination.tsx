import React, { memo } from "react";
import { PaginationButton } from "./PaginationButton";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export const Pagination = memo<PaginationProps>(
  ({ currentPage, totalPages, onPageChange }) => (
    <div className="flex space-x-3 mt-12 max-w-6xl mx-auto">
      <PaginationButton
        direction="prev"
        onClick={() => onPageChange(Math.max(0, currentPage - 1))}
        disabled={currentPage === 0}
      />
      <PaginationButton
        direction="next"
        onClick={() => onPageChange(Math.min(totalPages - 1, currentPage + 1))}
        disabled={currentPage === totalPages - 1}
      />
    </div>
  )
);

Pagination.displayName = "Pagination";
