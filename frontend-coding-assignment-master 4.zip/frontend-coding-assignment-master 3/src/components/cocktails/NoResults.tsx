import { messages } from "../../constants/messages";
import React, { memo } from "react";

export const NoResults = memo(() => {
  const message = messages[Math.floor(Math.random() * messages.length)];

  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-300px)]">
      <p className="text-white text-xl font-light">{message}</p>
    </div>
  );
});

NoResults.displayName = "NoResults";
