import React, { memo } from "react";

interface CategoryBadgeProps {
  category: string;
}

export const CategoryBadge = memo<CategoryBadgeProps>(({ category }) => (
  <span
    className="
      w-fit mt-2 px-2 py-1 
      border border-white/60 rounded-md 
      text-[11px] leading-[21px] font-['Varela Round']
      text-white text-center uppercase bg-black/20
    "
  >
    {category}
  </span>
));

CategoryBadge.displayName = "CategoryBadge";
