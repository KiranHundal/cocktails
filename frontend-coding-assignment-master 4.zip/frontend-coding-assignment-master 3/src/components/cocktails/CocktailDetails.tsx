import React, { memo, useRef, useEffect } from "react";
import { Cocktail } from "../../types/cocktail";
import { IngredientsList } from "./IngredientsList";
import { ShareSection } from "./ShareSection";
import { CategoryBadge } from "./CategoryBadge";
import { useApp } from "../../providers/AppProvider";

interface CocktailDetailsProps {
  cocktail: Cocktail;
}

export const CocktailDetails = memo<CocktailDetailsProps>(({ cocktail }) => {
  const { announceMessage } = useApp();
  const detailsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    announceMessage(`Showing details for ${cocktail.name}`);
  }, [cocktail.name, announceMessage]);

  return (
    <article
      ref={detailsRef}
      className="bg-black/30 rounded-3xl p-8 max-w-3xl mx-auto shadow-lg border border-white/60"
      aria-labelledby="cocktail-name"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <div className="relative">
          <img
            src={cocktail.image}
            alt={`${cocktail.name} cocktail presentation`}
            className="w-60 h-60 object-cover rounded-xl shadow-md"
          />
          <div className="mt-3">
            <CategoryBadge category={cocktail.category} />
          </div>
        </div>

        <IngredientsList ingredients={cocktail.ingredients} />
      </div>

      <div className="mt-10 space-y-6">
        <section aria-labelledby="instructions-heading">
          <h3
            id="instructions-heading"
            className="text-semi-white text-lg font-normal mb-3"
          >
            Instructions
          </h3>
          <p className="text-normal">{cocktail.instructions}</p>
        </section>

        <section aria-labelledby="glass-heading">
          <h3
            id="glass-heading"
            className="text-semi-white text-lg font-normal mb-3"
          >
            Glass Needed
          </h3>
          <p className="text-white font-['Varela Round'] text-[16px] leading-[24px] tracking-[-0.02em]">
            Serve in: {cocktail.container}
          </p>
        </section>

        <section aria-labelledby="share-heading">
          <h3
            id="share-heading"
            className="text-semi-white text-lg font-normal mb-3"
          >
            Share Link
          </h3>
          <ShareSection drinkName={cocktail.name} />
        </section>
      </div>
    </article>
  );
});

CocktailDetails.displayName = "CocktailDetails";
