import React, { memo } from "react";
import type { Ingredient } from "../../types/cocktail";

interface IngredientsListProps {
  ingredients: Ingredient[];
}

export const IngredientsList = memo<IngredientsListProps>(({ ingredients }) => (
  <section>
    <h3
      className="text-lg text-white font-semibold mb-4"
      style={{ color: "#FFFFFFB2" }}
    >
      {ingredients.length} Ingredients
    </h3>
    <div className="grid grid-cols-2 gap-y-2 gap-x-4">
      {ingredients.map((ingredient, index) => (
        <div
          key={`${ingredient.name}-${index}`}
          className="text-[16px] text-white/90 font-light"
        >
          {ingredient.measurement} {ingredient.name}
        </div>
      ))}
    </div>
  </section>
));

IngredientsList.displayName = "IngredientsList";
