import React from "react";
import { useNavigate } from "react-router-dom";

const CocktailNotFound: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center text-white text-center">
      <h2 className="text-3xl font-bold mb-4">No Drinks Found</h2>
      <p className="text-lg mb-6">Try searching for something else!</p>

      
      <button
        onClick={() => navigate("/")} 
        className="px-6 py-3 bg-white text-black font-bold rounded-md shadow-md hover:bg-gray-200 transition"
      >
        Go Back
      </button>
    </div>
  );
};

export default CocktailNotFound;
