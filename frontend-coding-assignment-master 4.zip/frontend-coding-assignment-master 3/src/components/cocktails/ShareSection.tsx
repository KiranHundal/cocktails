import React, { memo } from "react";
import { useClipboard } from "../../hooks/useClipboard";
import { Button } from "../common/Button";
import { getShareUrl } from "../../utils/urls";
import CopyIcon from "../../assets/Copy-Icon.svg";
import CheckIcon from "../../assets/Check-Icon.svg";

interface ShareSectionProps {
  drinkName: string;
}

export const ShareSection = memo<ShareSectionProps>(({ drinkName }) => {
  const { copied, copyToClipboard } = useClipboard();
  const shareUrl = getShareUrl(drinkName);

  return (
    <section>
      <div className="flex items-center gap-3">
        <input
          type="text"
          value={shareUrl}
          readOnly
          className="flex-1 px-4 py-3 bg-white text-black rounded-lg border border-white/20 outline-none"
        />
        <Button
          onClick={() => copyToClipboard(shareUrl)}
          variant="primary"
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 transition-all text-white rounded-lg shadow-md flex items-center gap-2"
        >
          <img
            src={copied ? CheckIcon : CopyIcon}
            alt={copied ? "Copied" : "Copy"}
            className="w-5 h-5"
          />
          {copied ? "Copied" : "Copy"}
        </Button>
      </div>
    </section>
  );
});

ShareSection.displayName = "ShareSection";
