import React, { memo, useRef } from "react";
import type { Cocktail } from "../../types/cocktail";
import { CategoryBadge } from "./CategoryBadge";
import { useApp } from "../../providers/AppProvider";

interface CocktailCardProps {
  cocktail: Cocktail;
  onClick: () => void;
  className?: string;
}

export const CocktailCard = memo<CocktailCardProps>(
  ({ cocktail, onClick, className = "" }) => {
    const { announceMessage } = useApp();
    const cardRef = useRef<HTMLDivElement>(null);

    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        onClick();
        announceMessage(`Viewing details for ${cocktail.name}`);
      }
    };

    return (
      <article
        ref={cardRef}
        className={`
        bg-black/50 rounded-lg border border-white/60 
        overflow-hidden cursor-pointer 
        hover:bg-opacity-70 focus-within:ring-2 
        focus-within:ring-white/50 transition-all duration-200
        flex items-center p-4 space-x-6 ${className}
      `}
        tabIndex={0}
        role="button"
        onClick={onClick}
        onKeyDown={handleKeyDown}
        aria-label={`View details for ${cocktail.name}, ${cocktail.category} cocktail`}
      >
        <img
          src={cocktail.image}
          alt=""
          className="w-32 h-32 object-cover rounded-lg flex-shrink-0"
          aria-hidden="true"
        />
        

        <div className="flex flex-col justify-center space-y-2">
          <h2 className="text-2xl tracking-tight font-varela text-white">
            {cocktail.name}
          </h2>
          <CategoryBadge category={cocktail.category} />
        </div>
      </article>
    );
  }
);

CocktailCard.displayName = "CocktailCard";
