import { useState, useCallback, useEffect } from "react";
import { searchCocktails } from "../services/apiService";
import { PAGINATION } from "../constants";
import type { Cocktail, SearchResponse } from "../types/cocktail";
import { useDebounce } from "./useDebounce";

const getFromCache = (key: string): SearchResponse | null => {
  const cachedData = localStorage.getItem(key);
  if (!cachedData) return null;

  try {
    const parsedData: SearchResponse = JSON.parse(cachedData);
    return parsedData;
  } catch (error) {
    console.error("Error parsing JSON:", error);
    return null;
  }
};

const setInCache = (key: string, data: SearchResponse) => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const useSearch = () => {
  const [query, setQuery] = useState<string>("");
  const [cocktails, setCocktails] = useState<Cocktail[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(PAGINATION.DEFAULT_PAGE);
  const [totalPages, setTotalPages] = useState<number>(0);

  const debouncedQuery = useDebounce(query, 300);

  const handleSearch = useCallback(async () => {
    setLoading(true);

    const cacheKey = `cocktail-search-${debouncedQuery}-${page}`;

    try {
      let data: SearchResponse | null = getFromCache(cacheKey);

      if (!data) {
        data = await searchCocktails(
          page * PAGINATION.ITEMS_PER_PAGE,
          PAGINATION.ITEMS_PER_PAGE,
          debouncedQuery
        );
        setInCache(cacheKey, data);
      }

      setCocktails(data?.drinks ?? []);
      setTotalPages(
        Math.ceil((data?.totalCount ?? 0) / PAGINATION.ITEMS_PER_PAGE)
      );
    } catch (error) {
      console.error("Error:", error);
      setCocktails([]);
    } finally {
      setLoading(false);
    }
  }, [debouncedQuery, page]);

  useEffect(() => {
    handleSearch();
  }, [page, handleSearch]);

  return {
    query,
    setQuery,
    cocktails,
    loading,
    page,
    setPage,
    totalPages,
    handleSearch,
  };
};
