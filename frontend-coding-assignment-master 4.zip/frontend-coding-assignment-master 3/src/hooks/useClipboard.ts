import { useState, useCallback } from "react";

export const useClipboard = (duration = 2000) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = useCallback(
    async (text: string) => {
      try {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        const timer = setTimeout(() => setCopied(false), duration);
        return () => clearTimeout(timer);
      } catch (err) {
        console.error("Failed to copy:", err);
      }
    },
    [duration]
  );

  return { copied, copyToClipboard };
};
