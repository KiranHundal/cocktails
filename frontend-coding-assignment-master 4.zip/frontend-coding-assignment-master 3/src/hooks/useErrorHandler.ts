import { useCallback } from "react";

export const useErrorHandler = () => {
  return useCallback((error: unknown) => {
    if (error instanceof Error) {
      console.error("Caught error:", error.message);
    } else {
      console.error("Unknown error:", error);
    }
  }, []);
};
