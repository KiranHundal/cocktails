import { useState, useEffect } from "react";
import { getCocktailDetails } from "../services/apiService";
import type { Cocktail } from "../types/cocktail";

export const useCocktailDetails = (id: string | undefined) => {
  const [state, setState] = useState<{
    cocktail: Cocktail | null;
    loading: boolean;
    error: Error | null;
  }>({
    cocktail: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let mounted = true;

    const fetchCocktail = async () => {
      if (!id) return;

      setState((prev) => ({ ...prev, loading: true, error: null }));
      try {
        const response = await getCocktailDetails(parseInt(id, 10));
        if (mounted) {
          setState({
            cocktail: response.drinks[0],
            loading: false,
            error: null,
          });
        }
      } catch (err) {
        if (mounted) {
          setState({
            cocktail: null,
            loading: false,
            error:
              err instanceof Error
                ? err
                : new Error("Failed to fetch cocktail"),
          });
        }
      }
    };

    fetchCocktail();
    return () => {
      mounted = false;
    };
  }, [id]);

  return state;
};
