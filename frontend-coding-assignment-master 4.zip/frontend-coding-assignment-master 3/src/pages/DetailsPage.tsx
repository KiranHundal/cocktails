import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { LoadingSpinner } from "../components/common/LoadingSpinner";
import { AppLayout } from "../components/layout";
import { useSearch } from "../hooks/useSearch";
import { useCocktailDetails } from "../hooks/useCocktailDetails";
import { CocktailDetails } from "../components/cocktails/CocktailDetails";
import CocktailNotFound from "../components/cocktails/CocktailNotFound";
import { PageHeader } from "../components/common";

const DetailsPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { cocktail, loading, error } = useCocktailDetails(id);
  const { query, setQuery, cocktails, handleSearch } = useSearch();
  const [noResults, setNoResults] = useState(false); 

  const handleSearchAndNavigate = async () => {
    setNoResults(false); 
    await handleSearch(); 

    if (cocktails.length > 0) {
      navigate(`/details/${cocktails[0].id}`); 
    } else {
      setNoResults(true);
    }
  };

  return (
    <AppLayout>
      <PageHeader
        showSearch
        query={query}
        setQuery={setQuery}
        handleSearch={handleSearchAndNavigate}
      />

      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] px-6">
        {loading ? (
          <LoadingSpinner />
        ) : error || noResults || !cocktail ? (
          <CocktailNotFound /> 
        ) : (
          <div className="w-full max-w-3xl">
            <h2 className="text-4xl text-white font-bold mb-6 text-left">
              {cocktail.name}
            </h2>
            <CocktailDetails cocktail={cocktail} />
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default DetailsPage;
