import React, { memo, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSearch } from "../hooks/useSearch";
import { CocktailCard } from "../components/cocktails/CocktailCard";
import { AppLayout } from "../components/layout/AppLayout";
import { LoadingSpinner, PageHeader, Pagination } from "../components/common";
import { NoResults } from "../components/cocktails/NoResults";
import { useApp } from "../providers/AppProvider";

const SearchPage = memo(() => {
  const navigate = useNavigate();
  const { announceMessage } = useApp();
  const gridRef = useRef<HTMLDivElement>(null);

  const {
    query,
    setQuery,
    cocktails,
    loading,
    page,
    setPage,
    totalPages,
    handleSearch,
  } = useSearch();

  const handleGridKeyDown = (e: React.KeyboardEvent) => {
    if (!gridRef.current) return;

    const cards = gridRef.current.querySelectorAll('[role="button"]');
    const currentIndex = Array.from(cards).findIndex(
      (card) => card === document.activeElement
    );

    switch (e.key) {
      case "ArrowRight":
        e.preventDefault();
        if (currentIndex < cards.length - 1) {
          (cards[currentIndex + 1] as HTMLElement).focus();
        }
        break;
      case "ArrowLeft":
        e.preventDefault();
        if (currentIndex > 0) {
          (cards[currentIndex - 1] as HTMLElement).focus();
        }
        break;
      case "ArrowDown":
        e.preventDefault();
        if (currentIndex + 2 < cards.length) {
          (cards[currentIndex + 2] as HTMLElement).focus();
        }
        break;
      case "ArrowUp":
        e.preventDefault();
        if (currentIndex - 2 >= 0) {
          (cards[currentIndex - 2] as HTMLElement).focus();
        }
        break;
    }
  };

  useEffect(() => {
    if (!loading && cocktails.length > 0) {
      const message = cocktails.length
        ? `Found ${cocktails.length} cocktails${query ? ` for "${query}"` : ""}`
        : "No cocktails found";
      announceMessage(message);
    }
  }, [cocktails, loading, query, announceMessage]);

  return (
    <AppLayout>
      <PageHeader
        showSearch
        query={query}
        setQuery={setQuery}
        handleSearch={handleSearch}
      />

      <main
        id="main-content"
        className="px-8 max-w-7xl mx-auto"
        aria-live="polite"
      >
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-semibold text-white mb-6">
            {query ? `Search: ${query}` : "All Drinks"}
          </h1>

          {loading ? (
            <LoadingSpinner />
          ) : cocktails.length === 0 ? (
            <NoResults />
          ) : (
            <>
              <div
                ref={gridRef}
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
                role="grid"
                aria-label="Cocktail search results"
                onKeyDown={handleGridKeyDown}
              >
                {cocktails.map((drink) => (
                  <CocktailCard
                    key={drink.id}
                    cocktail={drink}
                    onClick={() => {
                      navigate(`/details/${drink.id}`);
                      announceMessage(`Navigating to ${drink.name} details`);
                    }}
                  />
                ))}
              </div>

              {totalPages > 1 && (
                <nav aria-label="Pagination">
                  <Pagination
                    currentPage={page}
                    totalPages={totalPages}
                    onPageChange={(newPage) => {
                      setPage(newPage);
                      announceMessage(`Navigating to page ${newPage + 1}`);
                    }}
                  />
                </nav>
              )}
            </>
          )}
        </div>
      </main>
    </AppLayout>
  );
});

SearchPage.displayName = "SearchPage";

export default SearchPage;
